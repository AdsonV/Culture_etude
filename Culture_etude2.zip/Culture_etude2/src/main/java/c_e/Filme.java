package c_e;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Filme {

    int id;
    String nome;
    String diretor;
    String descricao;
    String genero;
    Date duracao;
    SimpleDateFormat data = new SimpleDateFormat("dd/MM/yyyy");

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDiretor() {
        return diretor;
    }

    public void setDiretor(String diretor) {
        this.diretor = diretor;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getDuracao() {
        return duracao;
    }

    public void setDuracao(Date duracao) {
        this.duracao = duracao;
    }

    public SimpleDateFormat getData() {
        return data;
    }

    public void setData(SimpleDateFormat data) {
        this.data = data;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    Date date;
    String dataFormatada = data.format(date);

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}