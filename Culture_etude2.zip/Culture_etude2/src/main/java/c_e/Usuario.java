package c_e;

public class Usuario {

    String nome;
    String email;
    String senha;
    String qtd_itens;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getQtd_itens() {
        return qtd_itens;
    }

    public void setQtd_itens(String qtd_itens) {
        this.qtd_itens = qtd_itens;
    }
}