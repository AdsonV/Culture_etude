package c_e;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Listar extends JFrame implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
