package c_e;

public class Deletar {
}
