package c_e;

public class Cadastrar {
}
